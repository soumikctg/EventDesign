const fakeData = [
    {
        id: 1,
        eventName: "Weddily",
        Description: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Commodi reiciendis illo sunt tenetur laboriosam ab facere earum esse mollitia optio autem fuga doloremque eaque unde, voluptatem voluptatibus, dicta eos accusantium.",
        location: "Dhaka",
        eventType: "Wedding"
    },
    {
        id: 2,
        eventName: "Weddily",
        Description: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Commodi reiciendis illo sunt tenetur laboriosam ab facere earum esse mollitia optio autem fuga doloremque eaque unde, voluptatem voluptatibus, dicta eos accusantium.",
        location: "Dhaka",
        eventType: "wedding"
    },
    {
        id: 3,
        eventName: "Weddily",
        Description: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Commodi reiciendis illo sunt tenetur laboriosam ab facere earum esse mollitia optio autem fuga doloremque eaque unde, voluptatem voluptatibus, dicta eos accusantium.",
        location: "Dhaka",
        eventType: "Birthday"
    },
    // Add more fake data entries here
];

export default fakeData;